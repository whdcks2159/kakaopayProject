package com.kakaopayproject.controller;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kakaopayproject.exception.AsyncConfig;
import com.kakaopayproject.service.SettService;
import com.kakaopayproject.vo.CurrSettInfo;
import com.kakaopayproject.vo.InsertData;
import com.kakaopayproject.vo.SettInfo;
/**
 * Handles requests for the application home page.
 */
@RestController
@RequestMapping("/main/*")
public class MainController {
	
	@Autowired
	private SettService settService;
	
    ObjectMapper mapper = new ObjectMapper();
	
	private static final Logger logger = LoggerFactory.getLogger(MainController.class);

    //�κ���ȸ
	@PostMapping(value = "/select" ,consumes = "application/json" , produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
	public SettInfo select(@RequestBody SettInfo settInfo) throws JsonProcessingException {
        SettInfo select = settService.select(settInfo.getManageNo());
        logger.info("select : " + select);
        logger.info("ī���ȣ : " + select.getCardNo());
        logger.info("��ȿ�Ⱓ : " + select.getExpirtDate());
        logger.info("CVC��ȣ : " + select.getCvcNo());
        logger.info("����/��� ���� : " + select.getStatu());
        logger.info("����/��� �ݾ� : " + Integer.parseInt(select.getSettAmt().trim()));
        logger.info("�ΰ���ġ�� : " + Integer.parseInt(select.getVatAmt().trim()));
        select.setCardNo(setCode(select.getCardNo()));
        String jsonStr = mapper.writeValueAsString(select);
        System.out.println("jsonStr : "+ jsonStr);

		return select;
	}
	//����ŷ
    public static String setCode(String code) {
		if (code == null) {
			return code;
		} else if (code.equals("")) {
			return code;
		}
		int a = code.length() - 9;
		String b = "";
		for (int i = 0; i < a; i++) {
			b += "*";
		}
		String regex = "(\\d{6})(\\d{"+a+"})(\\d{3})";
		code = code.replaceAll(regex, "$1"+b+"$3");
		return code;
	}
	//����
	@PostMapping(value = "/settInfo",consumes = "application/json",produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
	public SettInfo settInfo(@RequestBody SettInfo settInfo) throws JsonProcessingException {
		
		String manageNo = settService.settInfoInsert(settInfo);
		
		//��ü��ȸ
        List<InsertData> list =  settService.list();
        logger.info("list : " + list);
		//����ݾ�
        List<CurrSettInfo> currList =  settService.currList();
        logger.info("currList : " + currList);
        
        String jsonStr = mapper.writeValueAsString(list);
        System.out.println("list : "+ jsonStr);
        
        String jsonStr2 = mapper.writeValueAsString(currList);
        System.out.println("currList : "+ jsonStr2);
        settInfo.setManageNo(manageNo);
		return settInfo;
	}
	//���
	@PostMapping(value = "/settCnclInfo",consumes = "application/json",produces = {MediaType.APPLICATION_JSON_UTF8_VALUE})
	public SettInfo settCnclInfo(@RequestBody SettInfo settInfo) throws JsonProcessingException {
		logger.info("convert..."+settInfo);

        //���
		String manageNo = settService.settCnclInfoInsert(settInfo);
		
      	//��ü��ȸ
        List<InsertData> list =  settService.list();
        logger.info("list : " + list);
		//����ݾ�
        List<CurrSettInfo> currList =  settService.currList();
        logger.info("currList : " + currList);

        String jsonStr = mapper.writeValueAsString(list);
        System.out.println("list : "+ jsonStr);
        
        String jsonStr2 = mapper.writeValueAsString(currList);
        System.out.println("currList : "+ jsonStr2);
        settInfo.setManageNo(manageNo);
		return settInfo;
	}
}
