package com.kakaopayproject.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
/**
 * Handles requests for the application home page.
 */
@Controller
@RequestMapping("/enter/*")
public class EnterController {
	
	@GetMapping("/enter")
	public String enter() {
		return "home";
	}
}
