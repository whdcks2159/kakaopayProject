package com.kakaopayproject.service;

import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.kakaopayproject.controller.MainController;
import com.kakaopayproject.mapper.SettMapper;
import com.kakaopayproject.vo.CurrSettInfo;
import com.kakaopayproject.vo.InsertData;
import com.kakaopayproject.vo.SettInfo;

import lombok.Setter;

@Service
public class SettServiceImpl implements SettService {

	private static final Logger logger = LoggerFactory.getLogger(MainController.class);
	
    @Setter(onMethod_ = @Autowired) 
    private SettMapper settMapper;

    private String iv;
	private Key keySpec;
	
    @Override
    public List<InsertData> list() {
        return settMapper.list();
    }
    
    @Override
    public List<CurrSettInfo> currList() {
        return settMapper.currList();
    }
    
    @Override
    public List<InsertData> cnclList(String settSeq) {
        return settMapper.cnclList(settSeq);
    }
    
    @Override
    public SettInfo select(String settSeq) {
    	InsertData insertData = new InsertData();
    	String manageNo = settSeq.replace("0", "");
    	insertData = settMapper.select(manageNo);
    	String cardInfo[] = new String[3];
    	try {
    		cardInfo = (decrypt(insertData.getSettInfoStr().substring(103,403).trim())+"").split("\\|");
		} catch (UnsupportedEncodingException | GeneralSecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    	SettInfo settInfo = new SettInfo();
    	settInfo.setManageNo(insertData.getSettInfoStr().substring(14,34));			//������ȣ
    	settInfo.setOriManageNo(insertData.getSettInfoStr().substring(83,103));			//������ȣ
    	settInfo.setCardNo(cardInfo[0]);			//ī���ȣ
    	settInfo.setExpirtDate(cardInfo[1]);		//��ȿ�Ⱓ
    	settInfo.setCvcNo(cardInfo[2]);			//CVC��ȣ
    	settInfo.setSettAmt(insertData.getSettInfoStr().substring(63,73));			//����/��ұݾ�
    	settInfo.setVatAmt(insertData.getSettInfoStr().substring(73,83));			//�ΰ���
    	settInfo.setStatu(insertData.getSettInfoStr().substring(4,14));				//����/��һ���
    	settInfo.setRegDate(insertData.getSettInfoStr().substring(403,417));		//����Ͻ�

        return settInfo;
    }
    
    @Override
	public String getSeq() {
        return settMapper.getSeq();
	}
    
    //������һ���
    @Override
    public String settCnclInfoInsert(SettInfo settInfo) {
    	
		SimpleDateFormat format1 = new SimpleDateFormat ( "yyyyMMddHHmmss");
		Date time = new Date();
		String time1 = format1.format(time);
		settInfo.setRegDate(time1);
    	
    	//���ŷ� ��ȸ
        SettInfo select = select(settInfo.getOriManageNo());
        logger.info("select : " + select);
        
    	settInfo.setOriManageNo(select.getManageNo());		//���ŷ���ȣ
    	
    	//���ŷ��� �ش� ��Ұǵ� ��ü��ȸ
        List<InsertData> cnclList =  cnclList(settInfo.getOriManageNo());
        logger.info("cnclList : " + cnclList);

        int currAmt = Integer.parseInt(select.getSettAmt().trim());
        int currVatAmt = Integer.parseInt(select.getVatAmt().trim());
        
        if(!cnclList.isEmpty()) {
        	for (int i = 0; i < cnclList.size(); i++) {
            	currAmt = currAmt - Integer.parseInt(cnclList.get(i).getSettInfoStr().substring(63,73).trim());
            	currVatAmt = currVatAmt - Integer.parseInt(cnclList.get(i).getSettInfoStr().substring(73,83).trim());
        	}	
        }
        
        int vatAmt = 0;
    	if("".equals(settInfo.getVatAmt()) || settInfo.getVatAmt() == null) 
    		if(currAmt == Integer.parseInt(settInfo.getSettAmt()))
    			vatAmt = currVatAmt;
    		else
    			vatAmt = Integer.parseInt(settInfo.getSettAmt())/11;
    	else
    		vatAmt = Integer.parseInt(settInfo.getVatAmt());
    	
        try {
        	if(currAmt < Integer.parseInt(settInfo.getSettAmt()))		//��ұݾ��� ���ŷ��ݾ׺��� Ŭ ���
        		throw new Exception("��ұݾ��� ���ŷ��ݾ׺��� Ů�ϴ�");
        	if(currVatAmt < vatAmt)		//��Һΰ����ݾ��� ���ŷ��ΰ����ݾ׺��� Ŭ ���
        		throw new Exception("��Һΰ���ġ���� ���ŷ� �ΰ���ġ������ Ů�ϴ�");
        	if(currAmt == Integer.parseInt(settInfo.getSettAmt()) && currVatAmt - vatAmt > 0)		//��Һΰ����ݾ��� ���ŷ��ΰ����ݾ׺��� Ŭ ���
        		throw new Exception("��ü ��ҽ� �ΰ���ġ���� �����ֽ��ϴ�");
        	currAmt = currAmt- Integer.parseInt(settInfo.getSettAmt());
        	currVatAmt = currVatAmt - vatAmt;
    	} catch (Exception e) {  // Noncompliant - exception is lost (only message is preserved)
      		logger.info(e.getMessage());
    		return e.getMessage();
    	}
    	
    	//450�� String�� ����
		InsertData insertData = new InsertData();
		
    	String settInfoStr = "";
    	String cardInfoStr = select.getCardNo()+"|"+select.getExpirtDate()+"|"+select.getCvcNo();
    	String encrypt = "";
    	
    	//ī������ ��ȣȭ
    	try {
			AES256Util();
			encrypt = encrypt(cardInfoStr);
			String decrypt = decrypt(encrypt);
			System.out.println(encrypt);
			System.out.println(decrypt);  
		} catch (UnsupportedEncodingException | GeneralSecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
    	//������ȣ(sequence)
    	String seq = String.format("%020d", Integer.parseInt(getSeq()));
    	
    	//������ STRING ó��
    	settInfoStr = settInfoStr+String.format("%-10s", "CANCEL");//����
    	settInfoStr = settInfoStr+String.format("%-20s", seq);
    	settInfoStr = settInfoStr+String.format("%-20s", select.getCardNo());
    	settInfoStr = settInfoStr+String.format("%02d", 00);
    	settInfoStr = settInfoStr+String.format("%-4s", select.getExpirtDate());
    	settInfoStr = settInfoStr+String.format("%-3s", select.getCvcNo());
    	settInfoStr = settInfoStr+String.format("%10s", settInfo.getSettAmt());
    	settInfoStr = settInfoStr+String.format("%010d", vatAmt);
    	settInfoStr = settInfoStr+String.format("%-20s", settInfo.getOriManageNo());
    	settInfoStr = settInfoStr+String.format("%-300s", encrypt);
    	settInfoStr = settInfoStr+String.format("%-16s", settInfo.getRegDate());	//�߰��� ����
    	settInfoStr = settInfoStr+String.format("%-31s", "");
    	
    	settInfoStr = String.format("%4d", settInfoStr.trim().length())+settInfoStr;//����
    	
		insertData.setSettInfoStr(settInfoStr);
		insertData.setSettSeq(seq);
		insertData.setOriManageNo(settInfo.getOriManageNo());
		
		//������� �ݾ� ������Ʈ�� ����
		CurrSettInfo currSettInfo = new CurrSettInfo();
		currSettInfo.setManageNo(settInfo.getOriManageNo());
		currSettInfo.setSettAmt(currAmt+"");
		currSettInfo.setVatAmt(currVatAmt + "");
		
		settMapper.settCurrInfoUpdate(currSettInfo);
		settMapper.settInfoInsert(insertData);
        return seq;
    }
    
    //��������
    @Override
    public String settInfoInsert(SettInfo settInfo) {
		SimpleDateFormat format1 = new SimpleDateFormat ( "yyyyMMddHHmmss");
		Date time = new Date();
		String time1 = format1.format(time);
		settInfo.setRegDate(time1);
    	//450�� String�� ����
		InsertData insertData = new InsertData();
		
    	String settInfoStr = "";
    	String cardInfoStr = settInfo.getCardNo()+"|"+settInfo.getExpirtDate()+"|"+settInfo.getCvcNo();
    	String encrypt = "";
    	
    	//ī������ ��ȣȭ
    	try {
			AES256Util();
			encrypt = encrypt(cardInfoStr);
			String decrypt = decrypt(encrypt);
			System.out.println(encrypt);	//���ڵ�
			System.out.println(decrypt);  	//���ڵ�
		} catch (UnsupportedEncodingException | GeneralSecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
    	//������ȣ(sequence)
    	String seq = String.format("%020d", Integer.parseInt(getSeq()));
    	
    	int vatAmt = 0;
    	if("".equals(settInfo.getVatAmt()) || settInfo.getVatAmt() == null) 
    		vatAmt = Integer.parseInt(settInfo.getSettAmt())/11;
    	else
    		vatAmt = Integer.parseInt(settInfo.getVatAmt());
    	
    	//������ STRING ó��
    	settInfoStr = settInfoStr+String.format("%-10s", "PAYMENT");//����
    	settInfoStr = settInfoStr+String.format("%-20s", seq);
    	settInfoStr = settInfoStr+String.format("%-20s", settInfo.getCardNo());
    	settInfoStr = settInfoStr+String.format("%02d", Integer.parseInt(settInfo.getInstPeriod()));
    	settInfoStr = settInfoStr+String.format("%-4s", settInfo.getExpirtDate());
    	settInfoStr = settInfoStr+String.format("%-3s", settInfo.getCvcNo());
    	settInfoStr = settInfoStr+String.format("%10s", settInfo.getSettAmt());
    	settInfoStr = settInfoStr+String.format("%010d", vatAmt);
    	settInfoStr = settInfoStr+String.format("%-20s", "");
    	settInfoStr = settInfoStr+String.format("%-300s", encrypt);
    	settInfoStr = settInfoStr+String.format("%-16s", settInfo.getRegDate());
    	settInfoStr = settInfoStr+String.format("%-31s", "");
    	
    	settInfoStr = String.format("%4d", settInfoStr.trim().length())+settInfoStr;//����
    	
		insertData.setSettInfoStr(settInfoStr);
		insertData.setSettSeq(seq);
		insertData.setOriManageNo("");
        
		CurrSettInfo currSettInfo = new CurrSettInfo();
		currSettInfo.setManageNo(seq);
		currSettInfo.setSettAmt(settInfo.getSettAmt());
		currSettInfo.setVatAmt(Integer.parseInt(settInfo.getSettAmt())/11 + "");
		//������� �ݾ�
		settMapper.settCurrInfoInsert(currSettInfo);
		settMapper.settInfoInsert(insertData);
        return seq;
    }

	/**
	 * @param key
	 *            ��/��ȣȭ�� ���� Ű��(kakaopayprojectAcceptance(īī������ �հݱ��))
	 * @throws UnsupportedEncodingException
	 *            Ű���� ���̰� 16������ ��� �߻�
	 */
	final static String key = "kakaopayprojectAcceptance";

	public void AES256Util() throws UnsupportedEncodingException {
		this.iv = key.substring(0, 16);
		byte[] keyBytes = new byte[16];
		byte[] b = key.getBytes("UTF-8");
		int len = b.length;
		if (len > keyBytes.length) {
			len = keyBytes.length;
		}
		System.arraycopy(b, 0, keyBytes, 0, len);
		SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");

		this.keySpec = keySpec;
	}

	/**
	 * AES256 ���� ��ȣȭ �Ѵ�.
	 * 
	 * @param str
	 *            ��ȣȭ�� ���ڿ�
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws GeneralSecurityException
	 * @throws UnsupportedEncodingException
	 */
	public String encrypt(String str) throws NoSuchAlgorithmException,
			GeneralSecurityException, UnsupportedEncodingException {
		Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
		c.init(Cipher.ENCRYPT_MODE, keySpec, new IvParameterSpec(iv.getBytes()));
		byte[] encrypted = c.doFinal(str.getBytes("UTF-8"));
		String enStr = new String(Base64.encodeBase64(encrypted));
		return enStr;
	}

	/**
	 * AES256���� ��ȣȭ�� txt �� ��ȣȭ�Ѵ�.
	 * 
	 * @param str
	 *            ��ȣȭ�� ���ڿ�
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws GeneralSecurityException
	 * @throws UnsupportedEncodingException
	 */
	public String decrypt(String str) throws NoSuchAlgorithmException,
			GeneralSecurityException, UnsupportedEncodingException {
		Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
		c.init(Cipher.DECRYPT_MODE, keySpec, new IvParameterSpec(iv.getBytes()));
		byte[] byteStr = Base64.decodeBase64(str.getBytes());
		return new String(c.doFinal(byteStr), "UTF-8");
	}

}
