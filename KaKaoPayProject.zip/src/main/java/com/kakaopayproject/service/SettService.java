package com.kakaopayproject.service;

import java.util.List;

import com.kakaopayproject.vo.CurrSettInfo;
import com.kakaopayproject.vo.InsertData;
import com.kakaopayproject.vo.SettInfo;

public interface SettService {

	List<InsertData> list();
	
	List<CurrSettInfo> currList();
	
	String getSeq();

	String settInfoInsert(SettInfo settInfo);

	SettInfo select(String settSeq);

	List<InsertData> cnclList(String settSeq);

	String settCnclInfoInsert(SettInfo settInfo);
	
	/*int delete(CardInfo cardInfo);

	int edit(CardInfo cardInfo);*/
}
