package com.kakaopayproject.mapper;

import java.util.List;

import com.kakaopayproject.vo.CurrSettInfo;
import com.kakaopayproject.vo.InsertData;

public interface SettMapper {

	public abstract List<InsertData> list();

	public abstract List<CurrSettInfo> currList();
	
	public abstract InsertData select(String settSeq);

	public abstract int settInfoInsert(InsertData settInfoStr);
	
	public abstract String getSeq();

	public abstract List<InsertData> cnclList(String settSeq);

	//���� ���� �ݾ׸� ��������
	public abstract int settCurrInfoInsert(CurrSettInfo currSettInfo);
	
	public abstract int settCurrInfoUpdate(CurrSettInfo currSettInfo);
	
}
