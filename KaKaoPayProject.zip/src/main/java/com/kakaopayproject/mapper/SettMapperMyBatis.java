package com.kakaopayproject.mapper;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kakaopayproject.vo.CurrSettInfo;
import com.kakaopayproject.vo.InsertData;

@Repository
public class SettMapperMyBatis implements SettMapper {

    private SqlSessionTemplate sqlSessionTemplate;
    
    @Autowired
    public void setSqlMapClient(SqlSessionTemplate sqlSessionTemplate) {
        this.sqlSessionTemplate = sqlSessionTemplate;
    }
    //��ü��ȸ
    @Override
    public List<InsertData> list() {
        return sqlSessionTemplate.selectList("selectAllSettInfo");
    }
    //����/���
    @Override
    public int settInfoInsert(InsertData settInfoStr) {
        return sqlSessionTemplate.insert("settInfoInsert", settInfoStr);
    }
    
    //Seq ���
    @Override
    public String getSeq() {
        return sqlSessionTemplate.selectOne("selectSeq");
    }
    
    //��ȸ
    @Override
    public InsertData select(String settSeq) {
        return sqlSessionTemplate.selectOne("selectSettInfo",settSeq);
    }
    
    //��Ҹ���Ʈ ��ȸ
	@Override
	public List<InsertData> cnclList(String oriManageNo) {
		return sqlSessionTemplate.selectList("selectCnclSettInfo",oriManageNo);
	}
    
	//���� �����ݾ�
    @Override
    public int settCurrInfoInsert(CurrSettInfo currSettInfo) {
        return sqlSessionTemplate.insert("currSettInfoInsert", currSettInfo);
    }
    
    //���� �����ݾ׾�����Ʈ
    @Override
    public int settCurrInfoUpdate(CurrSettInfo currSettInfo) {
        return sqlSessionTemplate.insert("currSettInfoUpdate", currSettInfo);
    }
    
    //���� �����ݾ���ȸ
	@Override
	public List<CurrSettInfo> currList() {
        return sqlSessionTemplate.selectList("selectCurrSettInfo");
	}
    

}
