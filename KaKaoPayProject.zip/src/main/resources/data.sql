INSERT INTO SettInfo (settSeq,oriManageNo,settInfoStr) 
VALUES (0,'0','');

--INSERT INTO SettInfo (SETT_SEQ,cardNo, expirtDate, cvcNo, instPeriod, settAmt,vatAmt,regDate) 
--VALUES (NEXT VALUE FOR SETT_SEQ,'1234123412341234','1220', '123', '0', '1000', '100','20200523090922');
--
--INSERT INTO SettInfo (SETT_SEQ,cardNo, expirtDate, cvcNo, instPeriod, settAmt,vatAmt,regDate) 
--VALUES (NEXT VALUE FOR SETT_SEQ,'1234123412341235','1222', '123', '6', '10000000', '1000000','20200523090922');
--
--INSERT INTO CARDINFO (cardNo, expirtDate, cvcNo, instPeriod, settAmt,regDate) 
--VALUES (1234123412341236,'0620', '123', '12', 100, SYSDATE);
--
--INSERT INTO CARDINFO (cardNo, expirtDate, cvcNo, instPeriod, settAmt,regDate) 
--VALUES (1234123412341237,'0720', '123', '0', 0, SYSDATE);
