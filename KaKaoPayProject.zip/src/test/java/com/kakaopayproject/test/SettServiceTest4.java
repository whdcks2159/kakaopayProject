package com.kakaopayproject.test;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.google.gson.Gson;
import com.kakaopayproject.vo.SettInfo;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration({"file:src/main/webapp/WEB-INF/spring/root-context.xml","file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml"})
@Log4j
public class SettServiceTest4 {
	//����,��ȸ �׽�Ʈ
	//Restlet Client������ ����
	@Setter(onMethod_ = @Autowired)
	private WebApplicationContext ctx;

	private MockMvc mockMvc;
	
	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(ctx).build();
	}

	@Test
	public void testConvert() throws Exception {
		SimpleDateFormat format1 = new SimpleDateFormat ( "yyyyMMddHHmmss");
		Date time = new Date();
		String time1 = format1.format(time);
		
		SettInfo settInfo = new SettInfo();
		settInfo.setCardNo("1234123412344788");
		settInfo.setExpirtDate("2020");
		settInfo.setCvcNo("123");
		settInfo.setInstPeriod("0");
		settInfo.setSettAmt("100000");
		settInfo.setRegDate(time1);

		String jsonStr = new Gson().toJson(settInfo);
		
		log.info(jsonStr);
		mockMvc.perform(post("/main/settInfo")
		.contentType(MediaType.APPLICATION_JSON)
		.content(jsonStr))
		.andExpect(status().is(200));
		
		SettInfo settInfo2 = new SettInfo();
		settInfo2.setManageNo("00000000000000000001");
		String jsonStr2 = new Gson().toJson(settInfo2);
		
		log.info(jsonStr2);
		mockMvc.perform(post("/main/select")
		.contentType(MediaType.APPLICATION_JSON)
		.content(jsonStr2))
		.andExpect(status().is(200));

	}
}
