package com.kakaopayproject.test;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.google.gson.Gson;
import com.kakaopayproject.vo.SettInfo;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration({"file:src/main/webapp/WEB-INF/spring/root-context.xml","file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml"})
@Log4j
public class SettServiceTest6_CASE1 {
	//�׽�Ʈ case 1
	//Restlet Client������ ����
	@Setter(onMethod_ = @Autowired)
	private WebApplicationContext ctx;

	private MockMvc mockMvc;
	
	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(ctx).build();
	}

	@Test
	public void testConvert() throws Exception {
		SimpleDateFormat format1 = new SimpleDateFormat ( "yyyyMMddHHmmss");
		Date time = new Date();
		String time1 = format1.format(time);
		String jsonStr = "";
		
		//���� 11000��
		SettInfo settInfo = new SettInfo();
		settInfo.setCardNo("000000000000001");
		settInfo.setExpirtDate("2020");
		settInfo.setCvcNo("123");
		settInfo.setInstPeriod("0");
		settInfo.setSettAmt("11000");
		settInfo.setRegDate(time1);

		jsonStr = new Gson().toJson(settInfo);
		
		log.info(jsonStr);
		mockMvc.perform(post("/main/settInfo")
		.contentType(MediaType.APPLICATION_JSON)
		.content(jsonStr))
		.andExpect(status().is(200));
		
		
		//��� 1100�� 
		SettInfo settCnclInfo = new SettInfo();
		settCnclInfo.setOriManageNo("1");
		settCnclInfo.setSettAmt("1100");
		settCnclInfo.setVatAmt("100");
		settCnclInfo.setRegDate(time1);

		jsonStr = new Gson().toJson(settCnclInfo);
		
		log.info(jsonStr);
		mockMvc.perform(post("/main/settCnclInfo")
		.contentType(MediaType.APPLICATION_JSON)
		.content(jsonStr))
		.andExpect(status().is(200));

		//��� 3300�� 

		SettInfo settCnclInfo2 = new SettInfo();
		settCnclInfo2.setOriManageNo("1");
		settCnclInfo2.setSettAmt("3300");
		settCnclInfo2.setRegDate(time1);

		jsonStr = new Gson().toJson(settCnclInfo2);
		
		log.info(jsonStr);
		mockMvc.perform(post("/main/settCnclInfo")
		.contentType(MediaType.APPLICATION_JSON)
		.content(jsonStr))
		.andExpect(status().is(200));

		//��� 7000��  (����)
		
		SettInfo settCnclInfo3 = new SettInfo();
		settCnclInfo3.setOriManageNo("1");
		settCnclInfo3.setSettAmt("7000");
		settCnclInfo.setRegDate(time1);

		jsonStr = new Gson().toJson(settCnclInfo3);
		
		log.info(jsonStr);
		mockMvc.perform(post("/main/settCnclInfo")
		.contentType(MediaType.APPLICATION_JSON)
		.content(jsonStr))
		.andExpect(status().is(200));

		//��� 6000�� �ΰ���ġ�� 700 (����)
		SettInfo settCnclInfo4 = new SettInfo();
		settCnclInfo4.setOriManageNo("1");
		settCnclInfo4.setSettAmt("6600");
		settCnclInfo4.setVatAmt("700");
		settCnclInfo4.setRegDate(time1);

		jsonStr = new Gson().toJson(settCnclInfo4);
		
		log.info(jsonStr);
		mockMvc.perform(post("/main/settCnclInfo")
		.contentType(MediaType.APPLICATION_JSON)
		.content(jsonStr))
		.andExpect(status().is(200));
		
		//��� 6000�� �ΰ���ġ�� 700 (����)
		SettInfo settCnclInfo5 = new SettInfo();
		settCnclInfo5.setOriManageNo("1");
		settCnclInfo5.setSettAmt("6600");
		settCnclInfo5.setVatAmt("600");
		settCnclInfo5.setRegDate(time1);

		jsonStr = new Gson().toJson(settCnclInfo5);
		
		log.info(jsonStr);
		mockMvc.perform(post("/main/settCnclInfo")
		.contentType(MediaType.APPLICATION_JSON)
		.content(jsonStr))
		.andExpect(status().is(200));
		
		//��� 100��(����)
		SettInfo settCnclInfo6 = new SettInfo();
		settCnclInfo6.setOriManageNo("1");
		settCnclInfo6.setSettAmt("100");
		settCnclInfo6.setRegDate(time1);

		jsonStr = new Gson().toJson(settCnclInfo6);
		
		log.info(jsonStr);
		mockMvc.perform(post("/main/settCnclInfo")
		.contentType(MediaType.APPLICATION_JSON)
		.content(jsonStr))
		.andExpect(status().is(200));
		
	}
}
